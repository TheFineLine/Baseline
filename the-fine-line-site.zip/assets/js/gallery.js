function artworkCard(art) {
  const card = document.createElement("figure");
  card.className = "art-card";
  card.tabIndex = 0;
  card.setAttribute("role", "button");
  card.setAttribute("aria-label", `View ${art.title} full size`);
  card.innerHTML = `
    <div class="art-card__frame">
      <img src="${art.image}" alt="${art.title}" loading="lazy">
    </div>
    <figcaption>
      <span class="art-card__title">${art.title}</span>
      <span class="art-card__category">${art.category}</span>
    </figcaption>
  `;
  return card;
}

function renderGrid(containerId, artworks) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = "";
  artworks.forEach((art, i) => {
    const card = artworkCard(art);
    const open = () => openLightbox(artworks, i);
    card.addEventListener("click", open);
    card.addEventListener("keydown", e => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        open();
      }
    });
    container.appendChild(card);
  });
}

function renderFilters(artworks) {
  const bar = document.getElementById("filter-bar");
  if (!bar) return;
  const categories = ["All", ...new Set(artworks.map(a => a.category))];
  categories.forEach(cat => {
    const btn = document.createElement("button");
    btn.className = "filter-btn" + (cat === "All" ? " filter-btn--active" : "");
    btn.type = "button";
    btn.textContent = cat;
    btn.addEventListener("click", () => {
      bar.querySelectorAll(".filter-btn").forEach(b => b.classList.remove("filter-btn--active"));
      btn.classList.add("filter-btn--active");
      const filtered = cat === "All" ? artworks : artworks.filter(a => a.category === cat);
      renderGrid("full-grid", filtered);
    });
    bar.appendChild(btn);
  });
}

let lightboxList = [];
let lightboxIndex = 0;

function getLightbox() {
  let lb = document.getElementById("lightbox");
  if (lb) return lb;

  lb = document.createElement("div");
  lb.id = "lightbox";
  lb.className = "lightbox";
  lb.innerHTML = `
    <button class="lightbox__close" aria-label="Close">&times;</button>
    <button class="lightbox__nav lightbox__nav--prev" aria-label="Previous artwork">&#8249;</button>
    <div class="lightbox__figure">
      <img class="lightbox__image" src="" alt="">
      <div class="lightbox__caption"></div>
    </div>
    <button class="lightbox__nav lightbox__nav--next" aria-label="Next artwork">&#8250;</button>
  `;
  document.body.appendChild(lb);

  lb.querySelector(".lightbox__close").addEventListener("click", closeLightbox);
  lb.querySelector(".lightbox__nav--prev").addEventListener("click", () => stepLightbox(-1));
  lb.querySelector(".lightbox__nav--next").addEventListener("click", () => stepLightbox(1));
  lb.addEventListener("click", e => {
    if (e.target === lb) closeLightbox();
  });
  document.addEventListener("keydown", e => {
    if (!lb.classList.contains("lightbox--open")) return;
    if (e.key === "Escape") closeLightbox();
    if (e.key === "ArrowLeft") stepLightbox(-1);
    if (e.key === "ArrowRight") stepLightbox(1);
  });

  return lb;
}

function updateLightbox() {
  const lb = document.getElementById("lightbox");
  const art = lightboxList[lightboxIndex];
  lb.querySelector(".lightbox__image").src = art.image;
  lb.querySelector(".lightbox__image").alt = art.title;
  lb.querySelector(".lightbox__caption").textContent = `${art.title} — ${art.category}`;
}

function openLightbox(list, index) {
  lightboxList = list;
  lightboxIndex = index;
  const lb = getLightbox();
  updateLightbox();
  lb.classList.add("lightbox--open");
  document.body.classList.add("no-scroll");
}

function closeLightbox() {
  const lb = document.getElementById("lightbox");
  if (lb) lb.classList.remove("lightbox--open");
  document.body.classList.remove("no-scroll");
}

function stepLightbox(delta) {
  lightboxIndex = (lightboxIndex + delta + lightboxList.length) % lightboxList.length;
  updateLightbox();
}

document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("featured-grid")) {
    renderGrid("featured-grid", ARTWORKS.filter(a => a.featured));
  }
  if (document.getElementById("full-grid")) {
    renderFilters(ARTWORKS);
    renderGrid("full-grid", ARTWORKS);
  }
});
