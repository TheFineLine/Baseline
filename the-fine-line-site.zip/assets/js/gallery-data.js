const ARTWORKS = [
  {
    title: "BMF:3K — Trilogy Timeline",
    category: "Poster Design",
    image: "assets/images/artworks/bmf-3k-timeline-poster.jpg",
    description: "Concept timeline artwork for the BMF trilogy.",
    featured: true
  },
  {
    title: "The Human Capacity for Self Deception",
    category: "Character Design",
    image: "assets/images/artworks/human-capacity-self-deception.jpg",
    description: "Character line-up study.",
    featured: true
  },
  {
    title: "Act I — Concept Collage",
    category: "Concept Art",
    image: "assets/images/artworks/act-i-concept-collage.jpg",
    description: "Mixed-media concept board for Act I.",
    featured: true
  },
  {
    title: "Hooded Figure Study",
    category: "Character Study",
    image: "assets/images/artworks/hooded-figure-red-white.jpg",
    description: "Line study in red and white.",
    featured: true
  },
  {
    title: "Wraith Sketch",
    category: "Character Study",
    image: "assets/images/artworks/demon-face-wings-red.jpg",
    description: "Loose character sketch.",
    featured: false
  },
  {
    title: "Owl Study",
    category: "Line Study",
    image: "assets/images/artworks/owl-study-linework.jpg",
    description: "Signed linework study.",
    featured: false
  },
  {
    title: "Feather Study — Gold",
    category: "Line Study",
    image: "assets/images/artworks/feather-study-gold.jpg",
    description: "Signed linework study.",
    featured: false
  },
  {
    title: "Storm Wing Sketch",
    category: "Line Study",
    image: "assets/images/artworks/storm-wing-sketch.jpg",
    description: "Loose wing study.",
    featured: false
  },
  {
    title: "Feather Wave Study",
    category: "Line Study",
    image: "assets/images/artworks/feather-wave-study.jpg",
    description: "Abstract feather linework.",
    featured: false
  },
  {
    title: "Wing Study I",
    category: "Line Study",
    image: "assets/images/artworks/wing-study-white-01.jpg",
    description: "Signed linework study.",
    featured: false
  },
  {
    title: "Wing Study II",
    category: "Line Study",
    image: "assets/images/artworks/wing-study-yellow-01.jpg",
    description: "Loose wing study.",
    featured: false
  },
  {
    title: "Wing Study III",
    category: "Line Study",
    image: "assets/images/artworks/wing-study-red-01.jpg",
    description: "Loose wing study.",
    featured: false
  },
  {
    title: "Feather Study — Red",
    category: "Line Study",
    image: "assets/images/artworks/feather-study-red-02.jpg",
    description: "Loose feather study.",
    featured: false
  }
];
